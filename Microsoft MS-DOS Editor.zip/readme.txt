original by Microsoft

edit.com was taken from my old Windows 7 Pc 

If you're still on Windows 7, you can execute it normally

but if you're in Windows 10, you need DOSBox

Feel free to share
----------------------------------------------------------

By OldInternetTraveller
----------------------------------------------------------